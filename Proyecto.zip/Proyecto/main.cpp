#include <iostream>
#include "tareas.cpp"
#include "Estudiante.cpp"
#include "calificacion.cpp"
#include "materia.cpp"
#include "participacion.cpp"
#include "Lista.h"

using namespace std;

bool validateNRC(List<Materia> LL,string nrc){
bool result=true;

      for(int x=1;x<=LL.contador;x++){
           Materia m= LL.retrieve(x);

           if(m.get_NRC()==nrc){
             result=false;
           }
        }

return result;
}
int main()
{
    List<Materia> LM;
    List<estudiante> LE;
    List<Tarea> LT;
    List<Calificacion> LC;
    Materia a;
    estudiante b;
    Tarea c;
    Calificacion d;
    fecha f;
    int x,y,w;
    string Str,Str2;
    size_t pos;
    bool res;
do{
    cout<<"Con que deseas trabajar?"<<endl;
    cout<<"1.Materias"<<endl;
    cout<<"2.Estudiantes"<<endl;
    cout<<"3.Tareas"<<endl;
    cout<<"4.Salir"<<endl;
    cin>>x;
    cout<<endl;

    switch(x){

        case 1:
        do{
            cout<<"Que desea realizar?"<<endl<<endl;
            cout<<"1. Crear nueva materia"<<endl;
            cout<<"2. Ver las materias actuales"<<endl;
            cout<<"3. Ingresar un nuevo alumno en una materia"<<endl;
            cout<<"4. Ver los estudiantes de una materia"<<endl;
            cout<<"5. Ingresar una nueva tarea en una materia"<<endl;
            cout<<"6. Ver las tareas de una materia"<<endl;
            cout<<"7. Salir"<<endl;
            cin>>w;
            cout<<endl;

                switch(w){

                    case 1:
                        res=false;
                        while(res==false){
                            cout<<"Cual es el NRC de la materia?"<<endl;
                            cin>>Str;
                            res= validateNRC(LM,Str);
                        }
                        fflush(stdin);
                        a.set_NRC(Str);
                        cout<<"Cual es el nombre de la materia?"<<endl;
                        getline(cin,Str);
                        a.set_nombre(Str);
                        cout<<"Cual es la clave de la materia?"<<endl;
                        cin>>Str;
                        a.set_clave(Str);
                        cout<<"Cual es el modulo de la materia?"<<endl;
                        cin>>Str;
                        a.set_modulo(Str);
                        cout<<"Cual es el ciclo de la materia?"<<endl;
                        cin>>Str;
                        a.set_ciclo(Str);
                        cout<<"Cual es el aula de la materia?"<<endl;
                        cin>>Str;
                        a.set_Aula(Str);
                        cout<<"Cual es el horario de la materia?(HH:MM, 24HRS)"<<endl;
                        cout<<"Horario de Inicio:";
                        cin>>Str;
                        pos = Str.rfind(":");
                        Str2 = Str.substr(0, pos);
                        f.setHora(stoi(Str2));
                        Str2 = Str.substr(pos+1,Str.size() );
                        f.setMinuto(stoi(Str2));
                        a.set_Fecha_inicio(f);

                        cout<<"Hora en que termina:";
                        cin>>Str;
                        pos = Str.rfind(":");
                        Str2 = Str.substr(0, pos);
                        f.setHora(stoi(Str2));
                        Str2 = Str.substr(pos+1,Str.size() );
                        f.setMinuto(stoi(Str2));
                        /*
                        cout<<"Escriba los minutos a los que inicia la materia"<<endl;
                        cin>>y;
                        f.setMinuto(y);
                        cout<<"Escriba la hora a la que inicia la materia"<<endl;
                        cin>>y;

                        f.setHora(y);
                        a.set_Fecha_inicio(f);

                        cout<<"Escriba los minutos a los que termina la materia"<<endl;
                        cin>>y;
                        f.setMinuto(y);
                        cout<<"Escriba la hora a la que termina la materia"<<endl;
                        cin>>y;
                        f.setHora(y);
                          */
                        a.set_Fecha_fin(f);
                        fflush(stdin);
                        cout<<"Cuales dias se va a impartir la materia?"<<endl;
                        getline(cin,Str);
                        a.set_Dias(Str);
                        cout<<"Cual es la seccion de la materia?"<<endl;
                        cin>>Str;
                        a.set_Seccion(Str);
                        LM.insertInList(a);
                        cout<<endl;
                        break;

                    case 2:

                        LM.print_list();
                        break;

                    case 3:

                        cout<<"Escriba el NRC de la materia"<<endl;
                        cin>>Str;
                        cout<<"Escriba el codigo del estudiante que desea agregar a la materia"<<endl;
                        cin>>Str2;

                        for(int x=1;x<=LM.contador;x++){
                           Materia* m= LM.retrieve2(x);
                           if(m->get_NRC()==Str){
                            m->insertCodigoE(Str2);
                           }
                        }
                        cout<<endl;
                        break;

                    case 4:
                       cout<<"Escriba el NRC de la materia"<<endl;
                       cin>>Str;
                      cout<<"Los estudiantes de la materia son: ";
                      for(int x=1;x<=LM.contador;x++){
                           Materia m= LM.retrieve(x);

                           if(m.get_NRC()==Str){
                            m.printSE();
                           }

                        }
                        system("pause");
                        cout<<endl;
                        break;

                    case 5:
                        cout<<"Escriba el NRC de la materia"<<endl;
                        cin>>Str;
                        cout<<"Escriba el id de la tarea que desea agregar a la materia"<<endl;
                        cin>>y;

                        for(int x=1;x<=LM.contador;x++){
                           Materia* m= LM.retrieve2(x);
                           if(m->get_NRC()==Str){
                            m->insertCodigoT(y);
                           }
                        }
                        cout<<endl;
                        break;
                    case 6:
                        cout<<"Escriba el NRC de la materia"<<endl;
                        cin>>Str;
                        cout<<"Las tareas de la materia son: ";

                      for(int x=1;x<=LM.contador;x++){
                           Materia m= LM.retrieve(x);

                           if(m.get_NRC()==Str){
                            m.printST();
                           }

                        }
                        system("pause");
                        cout<<endl;
                        break;
                }
            }while(w!=7);
            break;

        case 2:

            do{
                cout<<"Que desea realizar?"<<endl<<endl;
                cout<<"1.Registrar nuevo alumno"<<endl;
                cout<<"2.Ver todos los alumnos registrados"<<endl;
                cout<<"3.Salir"<<endl;
                cin>>w;

                    switch(w)
                    {
                        case 1:

                            fflush(stdin);
                            cout<<"Cual es el nombre del estudiante?"<<endl;
                            getline(cin,Str);
                            b.set_Nombre(Str);
                            cout<<"Cual es el apellido del estudiante?"<<endl;
                            getline(cin,Str);
                            b.set_Apellido(Str);
                            cout<<"Cual es el codigo del estudiante?"<<endl;
                            getline(cin,Str);
                            b.set_Codigo(Str);
                            cout<<"Cual es la carrera del estudiante?"<<endl;
                            getline(cin,Str);
                            b.set_Carrera(Str);
                            cout<<"Cual es la correo del estudiante?"<<endl;
                            getline(cin,Str);
                            b.set_Correo(Str);
                            cout<<endl;
                            LE.insertInList(b);
                            break;

                        case 2:
                            LE.print_list();
                            break;
                    }
            }while(w!=3);
            break;

        case 3:

            do{
                cout<<"Que desea realizar?"<<endl<<endl;
                cout<<"1.Registrar nueva tarea"<<endl;
                cout<<"2.Ver todas las tareas registradas"<<endl;
                cout<<"3.Salir"<<endl;
                cin>>w;

                    switch(w)
                    {
                        case 1:

                            fflush(stdin);
                            cout<<"Cual es el nombre de la tarea?"<<endl;
                            getline(cin,Str);
                            c.setNombre(Str);
                            cout<<"Cual es la descripcion de la tarea?"<<endl;
                            getline(cin,Str);
                            c.setDesc(Str);
                            cout<<"Cual es el archivo asignacion de la tarea?"<<endl;
                            getline(cin,Str);
                            c.setArchivoAsignacion(Str);
                            cout<<"Cual es el id de la tarea?"<<endl;
                            cin>>y;
                            c.setId(y);
                            cout<<"Cual es la fecha de entrega de la tarea?"<<endl<<endl;
                            cout<<"Escriba el dia"<<endl;
                            f.setDia(y);
                            cout<<"Escriba el mes"<<endl;
                            f.setMes(y);
                            cout<<"Escriba el anio"<<endl;
                            f.setAnio(y);
                            cout<<"Escriba la hora"<<endl;
                            f.setHora(y);
                            cout<<"Escriba los minutos"<<endl;
                            f.setMinuto(y);
                            c.setFechaEntrega(f);
                            cout<<endl;
                            LT.insertInList(c);
                            break;

                        case 2:
                            LE.print_list();
                            break;
                    }
            }while(w!=3);
            break;
    }
}while(x!=4);

    return 0;
}
